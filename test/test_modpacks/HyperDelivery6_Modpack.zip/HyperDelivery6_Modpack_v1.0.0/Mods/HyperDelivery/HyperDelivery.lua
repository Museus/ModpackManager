ModUtil.RegisterMod("HyperDelivery")

ModUtil.WrapBaseFunction("DisplayLocationText", function( baseFunc, eventSource, args)
    if args.Text == "Location_Tartarus" then
        local funnytext = RandomChance(0.15)
        args.Text = "dragonsquad esports presents"
        if funnytext then
            args.Text = "soft pine flooring presents"
        end
        args.FontScale = 0.72
        baseFunc(eventSource, args)
        args.Text = "HYPER DELIVERY SIX"
        if funnytext then
            args.Text = "TIMBO'S SECURITY DEPOSIT"
        end
        args.Delay = 0.6
        args.FontScale = 1.0
        baseFunc(eventSource, args)
    else
        baseFunc(eventSource,args)
    end

end, HyperDelivery)


## Mod Credits

- [Museus](https://github.com/Museus)
  - HyperDeliveryModpack (Creator/Compiler/Tester)
  - InfiniDD (Author)
  - RemoveCutscenes (Author)
  - RemoveThanatos (Author)
  - SatyrSackControl (Author)
  - MinibossControl (Author)
  - PrintUtil (Author)
  - ShowChamberNumber (Author)

- [cgull](https://github.com/cgu11)
  - HyperDeliveryModpack (Creator/Compiler/Tester)
  - Chamber1EpicOnly (Author)
  - MoreMidshops (Author)
  - DontGetVorimed (Contributor)
  - LootChoiceExt (Contributor)
  - EllosStartingBoonSelectorMod (Contributor)
  - InfiniDD (Contributor)

- [Ellomenop](https://github.com/ellomenop)
  - EllosStartingBoonSelectorMod (Author)
  - DontGetVorimed (Author)
  - PrintUtil (Author)
  - ShowChamberNumber (Author)

- [MagicGonads](https://github.com/MagicGonads)
  - LootChoiceExt (Author)
  - ModUtil (Author)

- [Paradigmsort](https://github.com/parasHadesMods)
  - EllosStartingBoonSelectorMod (Contributor)

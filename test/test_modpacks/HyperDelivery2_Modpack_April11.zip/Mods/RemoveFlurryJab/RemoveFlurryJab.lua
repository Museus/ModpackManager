--[[
    Remove Flurry Jab
    Author:
        Museus (Discord: Museus#7777)

    Can be used to remove Flurry Jab from first or both hammers.
]]
ModUtil.RegisterMod("RemoveFlurryJab")

local config = {
    ModName = "RemoveFlurryJab",
    Enabled = true,
    RemoveFromBoth = false,
}

if ModConfigMenu then
  ModConfigMenu.Register(config)
end

-- Scripts/TraitScripts.lua : 1547
ModUtil.WrapBaseFunction("SetTraitsOnLoot", function ( baseFunc, lootData, args )

    args = args or {}
    args.ExclusionNames = args.ExclusionNames or {}

    -- If RemoveFlurryJab is enabled
    if config.Enabled then
        local hammerTraits = {}

        -- Check whether we have any hammers
        for i, trait in pairs( CurrentRun.Hero.Traits ) do
            if LootData.WeaponUpgrade.TraitIndex[trait.Name] then
                table.insert(hammerTraits, trait.Name )
            end
        end

        -- If this is our first hammer or Flurry removed from both
        if IsEmpty( hammerTraits ) or config.RemoveFromBoth then
            table.insert(args.ExclusionNames, "SpearAutoAttack")
        end
    end

    for _, excluded in pairs(args.ExclusionNames) do
        DebugPrint({Text = excluded})
    end

    baseFunc(lootData, args)
end, RemoveFlurryJab)

-- Scripts/RoomManager.lua : 1874
ModUtil.WrapBaseFunction("StartRoom", function ( baseFunc, currentRun, currentRoom )
    PrintUtil.showModdedWarning()

    baseFunc(currentRun, currentRoom)
end, RemoveFlurryJab)

-- Scripts/UIScripts.lua : 145
ModUtil.WrapBaseFunction("ShowCombatUI", function ( baseFunc, flag )
    PrintUtil.showModdedWarning()

    baseFunc(flag)
end, RemoveFlurryJab)